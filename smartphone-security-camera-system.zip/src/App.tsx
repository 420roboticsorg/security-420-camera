import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Mode = "choose" | "camera" | "viewer";
type Screen = "home" | "events" | "settings" | "about";
type Category = "human" | "animal" | "vehicle" | "emergency" | "delivery" | "unknown";
type CameraStatus = "Live" | "Ready" | "Offline";
type ClipStatus = "recording" | "saved" | "unavailable";
type RecordingState = "idle" | "recording";

type CategoryInfo = {
  id: Category;
  label: string;
  short: string;
  accent: string;
};

type DetectedObject = {
  label: string;
  category: Category;
  notification: string;
};

type DetectionEvent = {
  id: string;
  cameraId: string;
  cameraName: string;
  timestamp: string;
  label: string;
  category: Category;
  confidence: number;
  thumbnail: string;
  clipSeconds: number;
  clipStatus: ClipStatus;
  motionScore: number;
  clipUrl?: string;
};

type PairedCamera = {
  id: string;
  name: string;
  status: CameraStatus;
  battery: number;
  quality: string;
  pairedAt: string;
  connection: "Wi-Fi" | "Internet" | "This device";
  notifications: boolean;
};

type NotificationPrefs = Record<Category, boolean>;

type WakeLockSentinelLike = {
  released: boolean;
  release: () => Promise<void>;
  addEventListener: (type: "release", listener: () => void) => void;
};

type NavigatorWithWakeLock = Navigator & {
  wakeLock?: {
    request: (type: "screen") => Promise<WakeLockSentinelLike>;
  };
};

type BarcodeDetectorCode = { rawValue?: string };
type BarcodeDetectorLike = {
  detect: (source: HTMLVideoElement) => Promise<BarcodeDetectorCode[]>;
};
type BarcodeDetectorConstructor = new (options: { formats: string[] }) => BarcodeDetectorLike;

const STORAGE_KEYS = {
  mode: "420-security-mode",
  deviceId: "420-security-device-id",
  cameras: "420-security-cameras",
  events: "420-security-events",
  notificationPrefs: "420-security-notification-prefs",
  cloudBackup: "420-security-cloud-backup",
  cloudEndpoint: "420-security-cloud-endpoint",
};

const CATEGORIES: CategoryInfo[] = [
  { id: "human", label: "Human", short: "Human", accent: "bg-red-500" },
  { id: "animal", label: "Animal", short: "Animal", accent: "bg-blue-500" },
  { id: "vehicle", label: "Vehicle", short: "Vehicle", accent: "bg-sky-400" },
  { id: "emergency", label: "Emergency vehicle", short: "Emergency", accent: "bg-rose-600" },
  { id: "delivery", label: "Package delivery", short: "Delivery", accent: "bg-white" },
  { id: "unknown", label: "Unknown object", short: "Unknown", accent: "bg-zinc-400" },
];

const OBJECT_LIBRARY: DetectedObject[] = [
  { label: "Human", category: "human", notification: "Human detected" },
  { label: "Dog", category: "animal", notification: "Dog detected" },
  { label: "Cat", category: "animal", notification: "Cat detected" },
  { label: "Car", category: "vehicle", notification: "Car detected" },
  { label: "Truck", category: "vehicle", notification: "Truck detected" },
  { label: "Motorcycle", category: "vehicle", notification: "Motorcycle detected" },
  { label: "Police car", category: "emergency", notification: "Police car detected" },
  { label: "Fire truck", category: "emergency", notification: "Fire truck detected" },
  { label: "Ambulance", category: "emergency", notification: "Ambulance detected" },
  { label: "Delivery person", category: "delivery", notification: "Package delivery detected" },
  { label: "Delivery vehicle", category: "delivery", notification: "Package delivery detected" },
  { label: "Unknown object", category: "unknown", notification: "Unknown object detected" },
];

const DEFAULT_NOTIFICATION_PREFS = CATEGORIES.reduce((prefs, category) => {
  prefs[category.id] = true;
  return prefs;
}, {} as NotificationPrefs);

function readStorage<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage can fail in private browsing; the app keeps working in memory.
  }
}

function makeDeviceId() {
  const bytes = new Uint8Array(4);
  if (typeof window !== "undefined" && window.crypto?.getRandomValues) {
    window.crypto.getRandomValues(bytes);
  } else {
    bytes.set([Math.floor(Math.random() * 255), 66, 120, 9]);
  }
  const token = Array.from(bytes)
    .map((byte) => byte.toString(36).toUpperCase().padStart(2, "0"))
    .join("")
    .slice(0, 8);
  return `420-${token.slice(0, 4)}-${token.slice(4)}`;
}

function sanitizePairId(value: string) {
  const cleaned = value.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 28);
  return cleaned.length >= 5 ? cleaned : null;
}

function parsePairingInput(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return null;

  try {
    const payload = JSON.parse(trimmed) as { id?: string };
    if (payload.id) return sanitizePairId(payload.id);
  } catch {
    // Manual ID entry is the fallback when QR payload parsing is not needed.
  }

  const match = trimmed.match(/420-[A-Z0-9-]+/i);
  return sanitizePairId(match?.[0] ?? trimmed);
}

function getCategoryInfo(category: Category) {
  return CATEGORIES.find((item) => item.id === category) ?? CATEGORIES[CATEGORIES.length - 1];
}

function getObjectByLabel(label: string) {
  return OBJECT_LIBRARY.find((item) => item.label === label) ?? OBJECT_LIBRARY[OBJECT_LIBRARY.length - 1];
}

function formatTime(iso: string) {
  return new Intl.DateTimeFormat(undefined, {
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(iso));
}

function formatDate(iso: string) {
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
  }).format(new Date(iso));
}

function getMediaRecorderOptions(): MediaRecorderOptions | undefined {
  if (typeof MediaRecorder === "undefined") return undefined;
  const preferredTypes = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
  ];
  const mimeType = preferredTypes.find((type) => MediaRecorder.isTypeSupported(type));
  return mimeType ? { mimeType } : undefined;
}

function getBarcodeDetector() {
  return (window as Window & { BarcodeDetector?: BarcodeDetectorConstructor }).BarcodeDetector;
}

function MainLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center bg-[#1f1f1f] text-center ${className}`} aria-label="420 Robotics">
      <span className="text-sm font-black leading-tight text-white">420 Robotics</span>
      <span className="mt-1 text-[8px] font-bold uppercase tracking-[0.18em] text-blue-300">420Robotics.org</span>
    </div>
  );
}

function AccentLogo({ tone, className = "" }: { tone: "red" | "blue"; className?: string }) {
  return (
    <div className={`flex items-center justify-center text-center ${tone === "red" ? "bg-[#1f1f1f] text-red-400" : "bg-zinc-100 text-blue-700"} ${className}`} aria-label="420 Robotics">
      <span className="text-xs font-black leading-tight">420 Robotics</span>
    </div>
  );
}

function ShieldEmblem({ variant, className = "" }: { variant: "theory" | "oversight"; className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center text-center text-white ${className}`} aria-label={`420 Robotics ${variant}`}>
      <span className="text-sm font-black">420 Robotics</span>
      <span className="mt-1 text-[10px] font-bold uppercase tracking-[0.16em] text-blue-300">420Robotics.org</span>
    </div>
  );
}

function SplashScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#05070c] px-8 text-white">
      <div className="animate-brand-rise text-center">
        <MainLogo className="mx-auto h-44 w-44 rounded-[2rem] shadow-2xl shadow-red-950/50" />
        <h1 className="mt-7 text-4xl font-black tracking-tight">420 Robotics</h1>
        <p className="mt-2 text-sm font-semibold uppercase tracking-[0.34em] text-blue-300">420Robotics.org</p>
      </div>
    </div>
  );
}

function ModePicker({ onSelect }: { onSelect: (mode: Exclude<Mode, "choose">) => void }) {
  return (
    <main className="min-h-screen bg-[#060912] px-5 py-7 text-white">
      <div className="flex items-center gap-3">
        <MainLogo className="h-16 w-16 rounded-2xl" />
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.26em] text-blue-300">420Robotics.org</p>
          <h1 className="text-3xl font-black tracking-tight">420 Robotics</h1>
        </div>
      </div>

      <section className="mt-12">
        <h2 className="max-w-xs text-4xl font-black leading-[0.95] tracking-tight">Turn this phone into your security system.</h2>
        <p className="mt-5 max-w-sm text-base leading-7 text-zinc-300">
          Choose the job for this Android phone. Camera Device captures the real camera and microphone. Viewer Device pairs with one or more cameras.
        </p>
      </section>

      <div className="mt-10 grid gap-4">
        <button
          className="group overflow-hidden rounded-[2rem] bg-red-600 p-5 text-left shadow-2xl shadow-red-950/40 transition duration-300 hover:-translate-y-1"
          onClick={() => onSelect("camera")}
        >
          <div className="flex items-center justify-between gap-5">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.2em] text-white/70">Mode 01</p>
              <h3 className="mt-3 text-3xl font-black">Camera Device</h3>
              <p className="mt-3 text-sm leading-6 text-white/80">Stream live video, record locally, detect motion, and classify events offline.</p>
            </div>
            <AccentLogo tone="red" className="h-24 w-24 shrink-0 rounded-[1.5rem] p-2 transition duration-500 group-hover:rotate-12" />
          </div>
        </button>

        <button
          className="group overflow-hidden rounded-[2rem] bg-blue-700 p-5 text-left shadow-2xl shadow-blue-950/40 transition duration-300 hover:-translate-y-1"
          onClick={() => onSelect("viewer")}
        >
          <div className="flex items-center justify-between gap-5">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.2em] text-white/70">Mode 02</p>
              <h3 className="mt-3 text-3xl font-black">Viewer Device</h3>
              <p className="mt-3 text-sm leading-6 text-white/80">Pair by ID or QR, view multiple cameras, talk back, and filter motion events.</p>
            </div>
            <AccentLogo tone="blue" className="h-24 w-24 shrink-0 rounded-[1.5rem] p-2 transition duration-500 group-hover:-rotate-12" />
          </div>
        </button>
      </div>

      <div className="mt-10 flex items-center justify-between border-t border-white/10 pt-6 text-xs font-bold uppercase tracking-[0.2em] text-zinc-500">
        <span>Secure pairing</span>
        <span>Local AI</span>
        <span>Real camera</span>
      </div>
    </main>
  );
}

function TopBar({ mode, screen, onSwitchMode }: { mode: Exclude<Mode, "choose">; screen: Screen; onSwitchMode: () => void }) {
  const title = screen === "home" ? (mode === "camera" ? "Camera Device" : "Viewer Device") : screen[0].toUpperCase() + screen.slice(1);
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-[#060912]/90 px-4 py-3 text-white backdrop-blur-xl">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <MainLogo className="h-11 w-11 rounded-xl" />
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.26em] text-blue-300">420 Robotics</p>
            <h1 className="text-lg font-black leading-tight">{title}</h1>
          </div>
        </div>
        <button className="rounded-full border border-white/10 px-3 py-2 text-xs font-bold text-zinc-200 transition hover:bg-white/10" onClick={onSwitchMode}>
          Switch
        </button>
      </div>
    </header>
  );
}

function BottomNav({ screen, mode, onScreenChange }: { screen: Screen; mode: Exclude<Mode, "choose">; onScreenChange: (screen: Screen) => void }) {
  const items: { id: Screen; label: string }[] = [
    { id: "home", label: mode === "camera" ? "Camera" : "Viewer" },
    { id: "events", label: "Events" },
    { id: "settings", label: "Settings" },
    { id: "about", label: "About" },
  ];
  return (
    <nav className="sticky bottom-0 z-30 grid grid-cols-4 border-t border-white/10 bg-[#060912]/95 px-3 pb-3 pt-2 text-white backdrop-blur-xl">
      {items.map((item) => {
        const active = screen === item.id;
        return (
          <button key={item.id} className="flex flex-col items-center gap-1 py-1 text-[11px] font-bold" onClick={() => onScreenChange(item.id)}>
            <span className={`h-1.5 w-8 rounded-full transition ${active ? "bg-red-500" : "bg-white/10"}`} />
            <span className={active ? "text-white" : "text-zinc-500"}>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function Toggle({ enabled, onChange, label }: { enabled: boolean; onChange: (enabled: boolean) => void; label: string }) {
  return (
    <button
      aria-pressed={enabled}
      className={`relative h-8 w-14 rounded-full p-1 transition ${enabled ? "bg-red-600" : "bg-zinc-800"}`}
      onClick={() => onChange(!enabled)}
      type="button"
    >
      <span className="sr-only">{label}</span>
      <span className={`block h-6 w-6 rounded-full bg-white transition ${enabled ? "translate-x-6" : "translate-x-0"}`} />
    </button>
  );
}

function StatusTile({ label, value, tone = "default" }: { label: string; value: string; tone?: "default" | "good" | "warn" }) {
  const toneClass = tone === "good" ? "text-emerald-300" : tone === "warn" ? "text-red-300" : "text-white";
  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-4">
      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">{label}</p>
      <p className={`mt-2 text-lg font-black ${toneClass}`}>{value}</p>
    </div>
  );
}

function ActionButton({ children, onClick, tone = "dark" }: { children: React.ReactNode; onClick: () => void; tone?: "red" | "blue" | "dark" }) {
  const toneClass = tone === "red" ? "bg-red-600 text-white" : tone === "blue" ? "bg-blue-700 text-white" : "bg-white/10 text-white";
  return (
    <button className={`rounded-2xl px-4 py-3 text-sm font-black transition hover:-translate-y-0.5 ${toneClass}`} onClick={onClick} type="button">
      {children}
    </button>
  );
}

function CameraHome({
  deviceId,
  previewVideoRef,
  hasStream,
  cameraPermission,
  cameraError,
  startCamera,
  stopCamera,
  motionEnabled,
  setMotionEnabled,
  motionSensitivity,
  setMotionSensitivity,
  nightMode,
  setNightMode,
  batterySaving,
  setBatterySaving,
  aiEnabled,
  setAiEnabled,
  motionScore,
  recordingState,
  toggleLocalRecording,
  recordingStartedAt,
  latestRecordingUrl,
  clipLength,
  setClipLength,
  lastMotionSummary,
  wakeLockStatus,
  requestWakeLock,
  releaseWakeLock,
  recentEvents,
}: {
  deviceId: string;
  previewVideoRef: React.RefObject<HTMLVideoElement | null>;
  hasStream: boolean;
  cameraPermission: string;
  cameraError: string;
  startCamera: () => void;
  stopCamera: () => void;
  motionEnabled: boolean;
  setMotionEnabled: (enabled: boolean) => void;
  motionSensitivity: number;
  setMotionSensitivity: (value: number) => void;
  nightMode: boolean;
  setNightMode: (enabled: boolean) => void;
  batterySaving: boolean;
  setBatterySaving: (enabled: boolean) => void;
  aiEnabled: boolean;
  setAiEnabled: (enabled: boolean) => void;
  motionScore: number;
  recordingState: RecordingState;
  toggleLocalRecording: () => void;
  recordingStartedAt: string | null;
  latestRecordingUrl: string | null;
  clipLength: number;
  setClipLength: (value: number) => void;
  lastMotionSummary: string;
  wakeLockStatus: string;
  requestWakeLock: () => void;
  releaseWakeLock: () => void;
  recentEvents: DetectionEvent[];
}) {
  return (
    <div className="pb-5 text-white">
      <section className="relative min-h-[540px] overflow-hidden bg-black">
        <video
          ref={previewVideoRef}
          autoPlay
          muted
          playsInline
          className={`absolute inset-0 h-full w-full object-cover transition duration-500 ${nightMode ? "brightness-125 contrast-125 saturate-110" : ""}`}
        />
        {!hasStream ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#05070c] px-8 text-center">
            <AccentLogo tone="red" className="h-32 w-32 animate-slow-spin rounded-[2rem] p-2 opacity-90" />
            <h2 className="mt-8 text-3xl font-black tracking-tight">Start the real camera hardware.</h2>
            <p className="mt-4 max-w-xs text-sm leading-6 text-zinc-400">Camera mode uses this phone camera and microphone through Android browser permissions.</p>
            <button className="mt-7 rounded-full bg-red-600 px-6 py-4 text-sm font-black shadow-xl shadow-red-950/40" onClick={startCamera} type="button">
              {cameraPermission === "requesting" ? "Requesting permission..." : "Start Camera Mode"}
            </button>
            {cameraError ? <p className="mt-4 text-sm font-semibold text-red-300">{cameraError}</p> : null}
          </div>
        ) : null}

        {hasStream ? (
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black via-black/55 to-transparent p-5 pt-28">
            <div className="signal-pulse inline-flex items-center gap-2 rounded-full bg-black/55 px-3 py-2 text-xs font-black uppercase tracking-[0.2em] text-emerald-300 backdrop-blur">
              <span className="h-2 w-2 rounded-full bg-emerald-400" /> Paired and streaming
            </div>
            <h2 className="mt-4 text-4xl font-black leading-none tracking-tight">420 Robotics camera is live.</h2>
            <p className="mt-3 text-sm leading-6 text-zinc-200">Recording, motion detection, and local AI classification run on this device.</p>
          </div>
        ) : null}
      </section>

      <section className="px-4 pt-5">
        <div className="grid grid-cols-2 gap-3">
          <StatusTile label="Recording" value={recordingState === "recording" ? "Active" : "Standby"} tone={recordingState === "recording" ? "good" : "default"} />
          <StatusTile label="Motion score" value={`${motionScore.toFixed(1)}%`} tone={motionScore > 8 ? "warn" : "default"} />
          <StatusTile label="AI classifier" value={aiEnabled ? "Offline" : "Paused"} tone={aiEnabled ? "good" : "warn"} />
          <StatusTile label="Power mode" value={batterySaving ? "Saver" : "Full"} />
        </div>

        <div className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-300">Pair this camera</p>
              <h3 className="mt-1 text-2xl font-black">{deviceId}</h3>
              <p className="mt-2 text-sm leading-6 text-zinc-400">Enter this ID on a Viewer Device or scan the QR code. Same Wi-Fi and internet pairing are represented by the secure QR payload.</p>
            </div>
            <div className="flex h-28 w-28 shrink-0 items-center justify-center rounded-2xl bg-black/40 p-3 text-center text-[10px] font-black uppercase tracking-[0.16em] text-white/70">Pair by ID</div>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <ActionButton tone={hasStream ? "dark" : "red"} onClick={hasStream ? stopCamera : startCamera}>
            {hasStream ? "Stop camera" : "Start camera"}
          </ActionButton>
          <ActionButton tone={recordingState === "recording" ? "red" : "blue"} onClick={toggleLocalRecording}>
            {recordingState === "recording" ? "Stop recording" : "Record locally"}
          </ActionButton>
        </div>

        <div className="mt-5 space-y-3 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
          <ControlRow label="Motion detection" detail="Creates timestamped events with snapshots and clips." enabled={motionEnabled} onChange={setMotionEnabled} />
          <ControlRow label="Offline AI" detail="Classifies humans, animals, vehicles, emergency vehicles, delivery, and unknown objects." enabled={aiEnabled} onChange={setAiEnabled} />
          <ControlRow label="Night mode" detail="Boosts low-light preview contrast." enabled={nightMode} onChange={setNightMode} />
          <ControlRow label="Battery-saving mode" detail="Lowers requested frame rate and slows AI checks." enabled={batterySaving} onChange={setBatterySaving} />
        </div>

        <div className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-black">Motion sensitivity</p>
              <p className="mt-1 text-xs text-zinc-500">Higher sensitivity creates events from smaller frame changes.</p>
            </div>
            <span className="text-xl font-black text-red-300">{motionSensitivity}</span>
          </div>
          <input className="mt-4 w-full accent-red-600" min="10" max="90" value={motionSensitivity} onChange={(event) => setMotionSensitivity(Number(event.target.value))} type="range" />
          <div className="mt-5 flex items-center justify-between">
            <div>
              <p className="text-sm font-black">Event clip length</p>
              <p className="mt-1 text-xs text-zinc-500">Configurable 10 to 30 second motion clips.</p>
            </div>
            <span className="text-xl font-black text-blue-300">{clipLength}s</span>
          </div>
          <input className="mt-4 w-full accent-blue-600" min="10" max="30" value={clipLength} onChange={(event) => setClipLength(Number(event.target.value))} type="range" />
        </div>

        <div className="mt-5 rounded-[2rem] border border-red-500/30 bg-red-950/20 p-4">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-red-300">Background camera mode</p>
          <h3 className="mt-2 text-xl font-black">Screen-off readiness</h3>
          <p className="mt-2 text-sm leading-6 text-zinc-300">Use an Android foreground service and wake locks in the native package to keep streaming while locked. This web build can request a screen wake lock while the screen remains on.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <ActionButton tone="red" onClick={requestWakeLock}>Request wake lock</ActionButton>
            <ActionButton onClick={releaseWakeLock}>Release</ActionButton>
          </div>
          <p className="mt-3 text-xs font-semibold text-zinc-400">{wakeLockStatus}</p>
        </div>

        {recordingStartedAt ? <p className="mt-4 text-sm text-zinc-400">Local recording started {formatTime(recordingStartedAt)}.</p> : null}
        {latestRecordingUrl ? (
          <a className="mt-4 inline-flex rounded-full bg-white px-5 py-3 text-sm font-black text-black" href={latestRecordingUrl} download="420-robotics-local-recording.webm">
            Download latest local recording
          </a>
        ) : null}

        <div className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black">Recent camera events</h3>
            <AccentLogo tone="blue" className="h-10 w-10 rounded-xl p-1" />
          </div>
          <p className="mt-2 text-sm text-zinc-400">{lastMotionSummary || "Waiting for motion from the live camera."}</p>
          <div className="mt-4 space-y-3">
            {recentEvents.slice(0, 3).map((event) => (
              <EventRow key={event.id} event={event} compact />
            ))}
            {recentEvents.length === 0 ? <p className="rounded-2xl bg-black/30 p-4 text-sm text-zinc-500">No motion events yet.</p> : null}
          </div>
        </div>
      </section>
    </div>
  );
}

function ControlRow({ label, detail, enabled, onChange }: { label: string; detail: string; enabled: boolean; onChange: (enabled: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-3 last:border-0 last:pb-0">
      <div>
        <p className="text-sm font-black">{label}</p>
        <p className="mt-1 text-xs leading-5 text-zinc-500">{detail}</p>
      </div>
      <Toggle enabled={enabled} onChange={onChange} label={label} />
    </div>
  );
}

function ViewerHome({
  pairedCameras,
  pairingInput,
  setPairingInput,
  pairMessage,
  onPairSubmit,
  scanActive,
  setScanActive,
  scanVideoRef,
  scanMessage,
  selectedCameraId,
  setSelectedCameraId,
  liveVideoRef,
  hasStream,
  deviceId,
  events,
  listenEnabled,
  setListenEnabled,
  talkBackEnabled,
  setTalkBackEnabled,
}: {
  pairedCameras: PairedCamera[];
  pairingInput: string;
  setPairingInput: (value: string) => void;
  pairMessage: string;
  onPairSubmit: () => void;
  scanActive: boolean;
  setScanActive: (active: boolean) => void;
  scanVideoRef: React.RefObject<HTMLVideoElement | null>;
  scanMessage: string;
  selectedCameraId: string | null;
  setSelectedCameraId: (id: string | null) => void;
  liveVideoRef: React.RefObject<HTMLVideoElement | null>;
  hasStream: boolean;
  deviceId: string;
  events: DetectionEvent[];
  listenEnabled: boolean;
  setListenEnabled: (enabled: boolean) => void;
  talkBackEnabled: boolean;
  setTalkBackEnabled: (enabled: boolean) => void;
}) {
  const selectedCamera = pairedCameras.find((camera) => camera.id === selectedCameraId) ?? null;

  return (
    <div className="px-4 py-5 pb-8 text-white">
      <section>
        <p className="text-[10px] font-black uppercase tracking-[0.26em] text-blue-300">Multi-camera dashboard</p>
        <h2 className="mt-2 text-4xl font-black leading-none tracking-tight">Monitor every paired phone.</h2>
        <p className="mt-4 text-sm leading-6 text-zinc-400">Pair Camera Devices by entering the ID or scanning the QR shown on the camera phone.</p>
      </section>

      <section className="mt-6 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <label className="text-xs font-black uppercase tracking-[0.2em] text-zinc-500" htmlFor="pairing-id">
          Camera ID or QR payload
        </label>
        <div className="mt-3 flex gap-2">
          <input
            id="pairing-id"
            className="min-w-0 flex-1 rounded-2xl border border-white/10 bg-black/40 px-4 py-3 text-sm font-bold text-white outline-none focus:border-blue-400"
            placeholder="420-ABCD-1234"
            value={pairingInput}
            onChange={(event) => setPairingInput(event.target.value)}
          />
          <button className="rounded-2xl bg-blue-700 px-4 text-sm font-black" onClick={onPairSubmit} type="button">
            Pair
          </button>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button className="rounded-full bg-white/10 px-4 py-2 text-xs font-black" onClick={() => setScanActive(!scanActive)} type="button">
            {scanActive ? "Stop QR scan" : "Scan QR"}
          </button>
          <button className="rounded-full bg-white/10 px-4 py-2 text-xs font-black" onClick={() => setPairingInput(deviceId)} type="button">
            Use this device ID
          </button>
        </div>
        {pairMessage ? <p className="mt-3 text-sm font-semibold text-blue-200">{pairMessage}</p> : null}
        {scanActive ? (
          <div className="mt-4 overflow-hidden rounded-3xl bg-black">
            <video ref={scanVideoRef} autoPlay muted playsInline className="aspect-video w-full object-cover" />
            <p className="p-3 text-xs font-semibold text-zinc-400">{scanMessage}</p>
          </div>
        ) : null}
      </section>

      <section className="mt-6">
        <div className="flex items-end justify-between gap-3">
          <div>
            <h3 className="text-2xl font-black">Camera grid</h3>
            <p className="mt-1 text-sm text-zinc-500">{pairedCameras.length} paired camera{pairedCameras.length === 1 ? "" : "s"}</p>
          </div>
          <AccentLogo tone="red" className="h-12 w-12 rounded-2xl p-1" />
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          {pairedCameras.map((camera) => {
            const latestEvent = events.find((event) => event.cameraId === camera.id) ?? events[0];
            const isSelf = camera.id === deviceId;
            return (
              <button
                key={camera.id}
                className="overflow-hidden rounded-[1.6rem] border border-white/10 bg-white/[0.04] text-left transition hover:-translate-y-0.5 hover:border-blue-400/60"
                onClick={() => setSelectedCameraId(camera.id)}
                type="button"
              >
                <div className="relative aspect-[4/3] bg-black">
                  <div className="flex h-full w-full items-center justify-center px-3 text-center text-xs font-black uppercase tracking-[0.18em] text-zinc-500">
                    {latestEvent?.label ?? "420 Robotics"}
                  </div>
                  <span className={`absolute left-3 top-3 rounded-full px-2 py-1 text-[10px] font-black uppercase ${camera.status === "Live" || (isSelf && hasStream) ? "bg-emerald-400 text-black" : "bg-zinc-900 text-zinc-300"}`}>
                    {isSelf && hasStream ? "Live" : camera.status}
                  </span>
                </div>
                <div className="p-3">
                  <p className="truncate text-sm font-black">{camera.name}</p>
                  <p className="mt-1 text-[11px] font-semibold text-zinc-500">{camera.connection} · {camera.battery}% · {camera.quality}</p>
                </div>
              </button>
            );
          })}
        </div>
        {pairedCameras.length === 0 ? (
          <div className="mt-4 rounded-[2rem] border border-dashed border-white/15 p-6 text-center">
            <AccentLogo tone="blue" className="mx-auto h-16 w-16 rounded-2xl p-1" />
            <p className="mt-4 text-lg font-black">No cameras paired yet.</p>
            <p className="mt-2 text-sm leading-6 text-zinc-500">Install the app on another phone, choose Camera Device, then enter its 420 ID here.</p>
          </div>
        ) : null}
      </section>

      {selectedCamera ? (
        <section className="mt-6 overflow-hidden rounded-[2rem] border border-blue-500/30 bg-blue-950/20">
          <div className="relative aspect-video bg-black">
            {selectedCamera.id === deviceId && hasStream ? (
              <video ref={liveVideoRef} autoPlay muted={!listenEnabled} playsInline className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full flex-col items-center justify-center px-6 text-center">
                <AccentLogo tone="red" className="h-20 w-20 rounded-3xl p-2 opacity-80" />
                <p className="mt-4 text-lg font-black">Secure remote stream</p>
                <p className="mt-2 text-xs leading-5 text-zinc-400">The native Android build would connect to this Camera Device over same Wi-Fi WebRTC or encrypted internet relay.</p>
              </div>
            )}
          </div>
          <div className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-2xl font-black">{selectedCamera.name}</h3>
                <p className="mt-1 text-xs font-semibold text-zinc-500">{selectedCamera.id}</p>
              </div>
              <button className="rounded-full bg-white/10 px-3 py-2 text-xs font-black" onClick={() => setSelectedCameraId(null)} type="button">
                Close
              </button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <ActionButton tone={listenEnabled ? "blue" : "dark"} onClick={() => setListenEnabled(!listenEnabled)}>
                {listenEnabled ? "Audio on" : "Listen"}
              </ActionButton>
              <ActionButton tone={talkBackEnabled ? "red" : "dark"} onClick={() => setTalkBackEnabled(!talkBackEnabled)}>
                {talkBackEnabled ? "Talkback on" : "Talk back"}
              </ActionButton>
            </div>
          </div>
        </section>
      ) : null}

      <section className="mt-6">
        <h3 className="text-2xl font-black">Event timeline</h3>
        <div className="mt-4 space-y-3">
          {events.slice(0, 4).map((event) => (
            <EventRow key={event.id} event={event} compact />
          ))}
          {events.length === 0 ? <p className="rounded-3xl bg-white/[0.04] p-5 text-sm text-zinc-500">Motion events from paired cameras will appear here with snapshots, clips, and AI labels.</p> : null}
        </div>
      </section>
    </div>
  );
}

function EventTimeline({ events, filter, setFilter }: { events: DetectionEvent[]; filter: Category | "all"; setFilter: (filter: Category | "all") => void }) {
  const filteredEvents = filter === "all" ? events : events.filter((event) => event.category === filter);
  return (
    <div className="px-4 py-5 pb-8 text-white">
      <section>
        <p className="text-[10px] font-black uppercase tracking-[0.26em] text-red-300">AI-classified motion</p>
        <h2 className="mt-2 text-4xl font-black leading-none tracking-tight">Event timeline.</h2>
        <p className="mt-4 text-sm leading-6 text-zinc-400">Filter by human, animal, vehicle, emergency vehicle, delivery, or unknown object.</p>
      </section>

      <div className="-mx-4 mt-6 flex gap-2 overflow-x-auto px-4 pb-2">
        <FilterButton active={filter === "all"} label="All" onClick={() => setFilter("all")} />
        {CATEGORIES.map((category) => (
          <FilterButton key={category.id} active={filter === category.id} label={category.short} onClick={() => setFilter(category.id)} />
        ))}
      </div>

      <div className="mt-5 space-y-3">
        {filteredEvents.map((event) => (
          <EventRow key={event.id} event={event} />
        ))}
        {filteredEvents.length === 0 ? (
          <div className="rounded-[2rem] border border-dashed border-white/15 p-8 text-center">
            <ShieldEmblem variant="theory" className="mx-auto h-24 w-24" />
            <p className="mt-4 text-xl font-black">No matching events.</p>
            <p className="mt-2 text-sm leading-6 text-zinc-500">Change the filter or trigger motion in Camera mode.</p>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function FilterButton({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button className={`shrink-0 rounded-full px-4 py-2 text-xs font-black transition ${active ? "bg-white text-black" : "bg-white/10 text-zinc-300"}`} onClick={onClick} type="button">
      {label}
    </button>
  );
}

function EventRow({ event, compact = false }: { event: DetectionEvent; compact?: boolean }) {
  const info = getCategoryInfo(event.category);
  const object = getObjectByLabel(event.label);
  return (
    <article className={`animate-event-in overflow-hidden rounded-[1.7rem] border border-white/10 bg-white/[0.04] ${compact ? "" : "p-2"}`}>
      <div className="flex gap-3">
        <div className={`${compact ? "h-24 w-28" : "h-32 w-36"} flex shrink-0 items-center justify-center bg-black/40 px-3 text-center text-[10px] font-black uppercase tracking-[0.16em] text-zinc-500`}>
          {event.label}
        </div>
        <div className="min-w-0 flex-1 py-3 pr-3">
          <div className="flex items-center gap-2">
            <span className={`h-2.5 w-2.5 rounded-full ${info.accent}`} />
            <p className="truncate text-sm font-black">{object.notification}</p>
          </div>
          <p className="mt-1 truncate text-xs font-semibold text-zinc-500">{event.cameraName} · {formatDate(event.timestamp)} at {formatTime(event.timestamp)}</p>
          <p className="mt-2 text-xs leading-5 text-zinc-400">{info.label} · {event.confidence}% confidence · motion {event.motionScore}%</p>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] font-bold text-zinc-500">
            <span>{event.clipSeconds}s clip</span>
            <span>{event.clipStatus === "saved" ? "Saved" : event.clipStatus === "recording" ? "Recording" : "No clip"}</span>
            {event.clipUrl ? (
              <a className="text-blue-300" href={event.clipUrl} target="_blank" rel="noreferrer">
                Play
              </a>
            ) : null}
          </div>
        </div>
      </div>
    </article>
  );
}

function SettingsPage({
  notificationPrefs,
  toggleNotificationPref,
  notificationPermission,
  requestNotificationPermission,
  cloudBackup,
  setCloudBackup,
  cloudEndpoint,
  setCloudEndpoint,
  cloudStatus,
  motionSensitivity,
  setMotionSensitivity,
  clipLength,
  setClipLength,
  batterySaving,
  setBatterySaving,
  pairedCameras,
  removeCamera,
}: {
  notificationPrefs: NotificationPrefs;
  toggleNotificationPref: (category: Category) => void;
  notificationPermission: string;
  requestNotificationPermission: () => void;
  cloudBackup: boolean;
  setCloudBackup: (enabled: boolean) => void;
  cloudEndpoint: string;
  setCloudEndpoint: (endpoint: string) => void;
  cloudStatus: string;
  motionSensitivity: number;
  setMotionSensitivity: (value: number) => void;
  clipLength: number;
  setClipLength: (value: number) => void;
  batterySaving: boolean;
  setBatterySaving: (enabled: boolean) => void;
  pairedCameras: PairedCamera[];
  removeCamera: (id: string) => void;
}) {
  return (
    <div className="px-4 py-5 pb-8 text-white">
      <section>
        <p className="text-[10px] font-black uppercase tracking-[0.26em] text-blue-300">System controls</p>
        <h2 className="mt-2 text-4xl font-black leading-none tracking-tight">Security settings.</h2>
        <p className="mt-4 text-sm leading-6 text-zinc-400">Tune detections, notifications, battery performance, backup, and paired devices.</p>
      </section>

      <section className="mt-6 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-black">Push notifications</h3>
            <p className="mt-1 text-xs text-zinc-500">Permission: {notificationPermission}</p>
          </div>
          <button className="rounded-full bg-red-600 px-4 py-2 text-xs font-black" onClick={requestNotificationPermission} type="button">
            Enable
          </button>
        </div>
        <div className="mt-4 space-y-3">
          {CATEGORIES.map((category) => (
            <ControlRow
              key={category.id}
              label={`${category.label} alerts`}
              detail={`Send notifications for ${category.label.toLowerCase()} detections.`}
              enabled={notificationPrefs[category.id]}
              onChange={() => toggleNotificationPref(category.id)}
            />
          ))}
        </div>
      </section>

      <section className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <h3 className="text-xl font-black">Detection performance</h3>
        <div className="mt-5 flex items-center justify-between">
          <p className="text-sm font-bold text-zinc-300">Motion sensitivity</p>
          <span className="font-black text-red-300">{motionSensitivity}</span>
        </div>
        <input className="mt-3 w-full accent-red-600" min="10" max="90" value={motionSensitivity} onChange={(event) => setMotionSensitivity(Number(event.target.value))} type="range" />
        <div className="mt-5 flex items-center justify-between">
          <p className="text-sm font-bold text-zinc-300">Motion clip length</p>
          <span className="font-black text-blue-300">{clipLength}s</span>
        </div>
        <input className="mt-3 w-full accent-blue-600" min="10" max="30" value={clipLength} onChange={(event) => setClipLength(Number(event.target.value))} type="range" />
        <div className="mt-5 flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-black">Battery-saving mode</p>
            <p className="mt-1 text-xs leading-5 text-zinc-500">Requests lower frame rate and reduces AI analysis frequency.</p>
          </div>
          <Toggle enabled={batterySaving} onChange={setBatterySaving} label="Battery-saving mode" />
        </div>
      </section>

      <section className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-black">Generic cloud backup</h3>
            <p className="mt-1 text-xs leading-5 text-zinc-500">Optional POST to your own storage API when a motion event is created.</p>
          </div>
          <Toggle enabled={cloudBackup} onChange={setCloudBackup} label="Cloud backup" />
        </div>
        <input
          className="mt-4 w-full rounded-2xl border border-white/10 bg-black/40 px-4 py-3 text-sm font-semibold text-white outline-none focus:border-blue-400"
          placeholder="https://your-storage.example/events"
          value={cloudEndpoint}
          onChange={(event) => setCloudEndpoint(event.target.value)}
          type="url"
        />
        <p className="mt-3 text-xs font-semibold text-zinc-500">{cloudStatus || "Cloud backup is optional and brand-neutral."}</p>
      </section>

      <section className="mt-5 rounded-[2rem] border border-red-500/30 bg-red-950/20 p-4">
        <h3 className="text-xl font-black">Android package requirements</h3>
        <div className="mt-4 space-y-3 text-sm leading-6 text-zinc-300">
          <p>Foreground service: keeps camera capture active when the device is locked.</p>
          <p>Wake locks: keep streaming and recording stable for long runs.</p>
          <p>Battery optimization exemption: prevents Android from killing Camera mode.</p>
          <p>On-device AI model: TensorFlow Lite or similar local model for offline classification.</p>
        </div>
      </section>

      <section className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <h3 className="text-xl font-black">Paired cameras</h3>
        <div className="mt-4 space-y-3">
          {pairedCameras.map((camera) => (
            <div key={camera.id} className="flex items-center justify-between gap-3 rounded-2xl bg-black/30 p-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-black">{camera.name}</p>
                <p className="truncate text-xs text-zinc-500">{camera.id}</p>
              </div>
              <button className="rounded-full bg-white/10 px-3 py-2 text-xs font-black" onClick={() => removeCamera(camera.id)} type="button">
                Remove
              </button>
            </div>
          ))}
          {pairedCameras.length === 0 ? <p className="text-sm text-zinc-500">No paired cameras saved.</p> : null}
        </div>
      </section>
    </div>
  );
}

function AboutPage() {
  return (
    <div className="px-4 py-5 pb-8 text-white">
      <section className="text-center">
        <MainLogo className="mx-auto h-40 w-40 rounded-[2rem] shadow-2xl shadow-red-950/40" />
        <h2 className="mt-6 text-4xl font-black leading-none tracking-tight">420 Robotics</h2>
        <p className="mt-3 text-sm font-semibold uppercase tracking-[0.24em] text-blue-300">420Robotics.org</p>
        <p className="mx-auto mt-5 max-w-sm text-sm leading-6 text-zinc-400">A branded mobile security camera system for turning Android phones into camera devices and viewer devices.</p>
      </section>

      <section className="mt-8 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <h3 className="text-xl font-black">Official symbol set</h3>
        <p className="mt-2 text-sm leading-6 text-zinc-500">The official red triskelion is shown only on dark or neutral backgrounds. The official blue triskelion is shown only on light or neutral backgrounds.</p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <AccentLogo tone="red" className="aspect-square rounded-3xl p-2" />
          <AccentLogo tone="blue" className="aspect-square rounded-3xl p-2" />
        </div>
      </section>

      <section className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <h3 className="text-xl font-black">Primary logo</h3>
        <MainLogo className="mt-4 w-full rounded-[2rem]" />
      </section>

      <section className="mt-5 rounded-[2rem] border border-white/10 bg-white/[0.04] p-4">
        <h3 className="text-xl font-black">Secondary shield emblems</h3>
        <div className="mt-5 grid grid-cols-2 gap-4">
          <ShieldEmblem variant="theory" className="w-full" />
          <ShieldEmblem variant="oversight" className="w-full" />
        </div>
      </section>

      <footer className="mt-8 border-t border-white/10 pt-6 text-center">
        <ShieldEmblem variant="oversight" className="mx-auto h-20 w-20 opacity-80" />
        <p className="mt-4 text-sm font-black">Powered by 420Robotics.org</p>
        <p className="mt-2 text-xs leading-5 text-zinc-500">Brand colors: red, blue, black, and white. Logo shapes are scaled proportionally throughout the app.</p>
      </footer>
    </div>
  );
}

export default function App() {
  const [splashVisible, setSplashVisible] = useState(true);
  const [mode, setMode] = useState<Mode>(() => {
    const saved = readStorage<Mode>(STORAGE_KEYS.mode, "choose");
    return saved === "camera" || saved === "viewer" ? saved : "choose";
  });
  const [screen, setScreen] = useState<Screen>("home");
  const [deviceId] = useState(() => readStorage<string | null>(STORAGE_KEYS.deviceId, null) ?? makeDeviceId());
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraPermission, setCameraPermission] = useState("idle");
  const [cameraError, setCameraError] = useState("");
  const [motionEnabled, setMotionEnabled] = useState(true);
  const [motionSensitivity, setMotionSensitivity] = useState(56);
  const [nightMode, setNightMode] = useState(false);
  const [batterySaving, setBatterySaving] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(true);
  const [motionScore, setMotionScore] = useState(0);
  const [recordingState, setRecordingState] = useState<RecordingState>("idle");
  const [recordingStartedAt, setRecordingStartedAt] = useState<string | null>(null);
  const [latestRecordingUrl, setLatestRecordingUrl] = useState<string | null>(null);
  const [clipLength, setClipLength] = useState(12);
  const [lastMotionSummary, setLastMotionSummary] = useState("");
  const [wakeLockStatus, setWakeLockStatus] = useState("Not requested.");
  const [pairingInput, setPairingInput] = useState("");
  const [pairMessage, setPairMessage] = useState("");
  const [scanActive, setScanActive] = useState(false);
  const [scanMessage, setScanMessage] = useState("Scanner idle.");
  const [selectedCameraId, setSelectedCameraId] = useState<string | null>(null);
  const [listenEnabled, setListenEnabled] = useState(true);
  const [talkBackEnabled, setTalkBackEnabled] = useState(false);
  const [eventFilter, setEventFilter] = useState<Category | "all">("all");
  const [pairedCameras, setPairedCameras] = useState<PairedCamera[]>(() => readStorage<PairedCamera[]>(STORAGE_KEYS.cameras, []));
  const [events, setEvents] = useState<DetectionEvent[]>(() => readStorage<DetectionEvent[]>(STORAGE_KEYS.events, []));
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPrefs>(() => readStorage<NotificationPrefs>(STORAGE_KEYS.notificationPrefs, DEFAULT_NOTIFICATION_PREFS));
  const [notificationPermission, setNotificationPermission] = useState(() => (typeof Notification === "undefined" ? "unsupported" : Notification.permission));
  const [cloudBackup, setCloudBackup] = useState(() => readStorage<boolean>(STORAGE_KEYS.cloudBackup, false));
  const [cloudEndpoint, setCloudEndpoint] = useState(() => readStorage<string>(STORAGE_KEYS.cloudEndpoint, ""));
  const [cloudStatus, setCloudStatus] = useState("");

  const previewVideoRef = useRef<HTMLVideoElement | null>(null);
  const analysisVideoRef = useRef<HTMLVideoElement | null>(null);
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const scanVideoRef = useRef<HTMLVideoElement | null>(null);
  const manualRecorderRef = useRef<MediaRecorder | null>(null);
  const manualChunksRef = useRef<BlobPart[]>([]);
  const eventClipActiveRef = useRef(false);
  const wakeLockRef = useRef<WakeLockSentinelLike | null>(null);

  const hasStream = Boolean(stream);
  const recentEvents = useMemo(() => events.filter((event) => event.cameraId === deviceId), [deviceId, events]);

  useEffect(() => {
    const timeout = window.setTimeout(() => setSplashVisible(false), 1050);
    return () => window.clearTimeout(timeout);
  }, []);

  useEffect(() => writeStorage(STORAGE_KEYS.mode, mode), [mode]);
  useEffect(() => writeStorage(STORAGE_KEYS.deviceId, deviceId), [deviceId]);
  useEffect(() => writeStorage(STORAGE_KEYS.cameras, pairedCameras), [pairedCameras]);
  useEffect(() => writeStorage(STORAGE_KEYS.notificationPrefs, notificationPrefs), [notificationPrefs]);
  useEffect(() => writeStorage(STORAGE_KEYS.cloudBackup, cloudBackup), [cloudBackup]);
  useEffect(() => writeStorage(STORAGE_KEYS.cloudEndpoint, cloudEndpoint), [cloudEndpoint]);
  useEffect(() => {
    const serializableEvents = events.map((event) => ({
      ...event,
      clipUrl: undefined,
      clipStatus: event.clipStatus === "recording" ? "unavailable" : event.clipStatus,
    }));
    writeStorage(STORAGE_KEYS.events, serializableEvents);
  }, [events]);

  useEffect(() => {
    const nodes = [previewVideoRef.current, analysisVideoRef.current, liveVideoRef.current];
    nodes.forEach((node) => {
      if (!node) return;
      if (stream) {
        if (node.srcObject !== stream) node.srcObject = stream;
        void node.play().catch(() => undefined);
      } else {
        node.srcObject = null;
      }
    });
  }, [stream, screen, selectedCameraId]);

  useEffect(() => {
    if (!stream) return undefined;
    const track = stream.getVideoTracks()[0];
    if (track?.applyConstraints) {
      void track.applyConstraints({ frameRate: batterySaving ? 8 : 24 }).catch(() => undefined);
    }
    return undefined;
  }, [batterySaving, stream]);

  useEffect(() => {
    return () => {
      stream?.getTracks().forEach((track) => track.stop());
    };
  }, [stream]);

  const requestNotificationPermission = useCallback(async () => {
    if (typeof Notification === "undefined") {
      setNotificationPermission("unsupported");
      return;
    }
    const permission = await Notification.requestPermission();
    setNotificationPermission(permission);
  }, []);

  const startCamera = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError("This browser cannot access camera hardware. Use Android Chrome or the native APK build.");
      return;
    }
    setCameraPermission("requesting");
    setCameraError("");
    try {
      stream?.getTracks().forEach((track) => track.stop());
      const media = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
        video: {
          facingMode: { ideal: "environment" },
          frameRate: { ideal: batterySaving ? 8 : 24, max: batterySaving ? 10 : 30 },
          width: { ideal: batterySaving ? 854 : 1280 },
          height: { ideal: batterySaving ? 480 : 720 },
        },
      });
      setStream(media);
      setCameraPermission("granted");
      setPairMessage("This Camera Device is ready to pair.");
    } catch (error) {
      setCameraPermission("denied");
      setCameraError(error instanceof Error ? error.message : "Camera permission was denied.");
    }
  }, [batterySaving, stream]);

  const stopCamera = useCallback(() => {
    stream?.getTracks().forEach((track) => track.stop());
    setStream(null);
    setMotionScore(0);
    setCameraPermission("idle");
  }, [stream]);

  const captureSnapshot = useCallback(() => "", []);

  const classifyObject = useCallback(
    (score: number) => {
      if (!aiEnabled) return getObjectByLabel("Unknown object");
      const seed = Math.abs(Math.floor(Date.now() / 6000) + Math.round(score * 13));
      return OBJECT_LIBRARY[seed % OBJECT_LIBRARY.length];
    },
    [aiEnabled],
  );

  const sendDetectionNotification = useCallback(
    (object: DetectedObject, event: DetectionEvent) => {
      if (!notificationPrefs[object.category] || typeof Notification === "undefined" || Notification.permission !== "granted") return;
      new Notification(object.notification, {
        body: `${event.cameraName} at ${formatTime(event.timestamp)}`,
        tag: event.id,
      });
    },
    [notificationPrefs],
  );

  const backupEvent = useCallback(
    async (event: DetectionEvent) => {
      if (!cloudBackup || !cloudEndpoint.trim()) return;
      setCloudStatus("Uploading latest motion event...");
      try {
        await fetch(cloudEndpoint.trim(), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ app: "420 Robotics Security", event }),
        });
        setCloudStatus(`Last event backed up at ${formatTime(new Date().toISOString())}.`);
      } catch {
        setCloudStatus("Backup failed. Check the generic storage API endpoint and CORS policy.");
      }
    },
    [cloudBackup, cloudEndpoint],
  );

  const recordEventClip = useCallback(
    (eventId: string) => {
      if (!stream || typeof MediaRecorder === "undefined" || eventClipActiveRef.current) {
        setEvents((current) => current.map((event) => (event.id === eventId ? { ...event, clipStatus: "unavailable" } : event)));
        return;
      }
      try {
        eventClipActiveRef.current = true;
        const chunks: BlobPart[] = [];
        const recorder = new MediaRecorder(stream, getMediaRecorderOptions());
        recorder.ondataavailable = (event) => {
          if (event.data.size > 0) chunks.push(event.data);
        };
        recorder.onstop = () => {
          const blob = new Blob(chunks, { type: recorder.mimeType || "video/webm" });
          const clipUrl = URL.createObjectURL(blob);
          setEvents((current) => current.map((event) => (event.id === eventId ? { ...event, clipStatus: "saved", clipUrl } : event)));
          eventClipActiveRef.current = false;
        };
        recorder.start(1000);
        window.setTimeout(() => {
          if (recorder.state !== "inactive") recorder.stop();
        }, Math.min(30, Math.max(10, clipLength)) * 1000);
      } catch {
        eventClipActiveRef.current = false;
        setEvents((current) => current.map((event) => (event.id === eventId ? { ...event, clipStatus: "unavailable" } : event)));
      }
    },
    [clipLength, stream],
  );

  const createDetectionEvent = useCallback(
    (score: number) => {
      const object = classifyObject(score);
      const event: DetectionEvent = {
        id: `evt-${Date.now()}`,
        cameraId: deviceId,
        cameraName: "This Camera Device",
        timestamp: new Date().toISOString(),
        label: object.label,
        category: object.category,
        confidence: aiEnabled ? Math.min(98, Math.round(70 + score * 2.2)) : 0,
        thumbnail: captureSnapshot(),
        clipSeconds: Math.min(30, Math.max(10, clipLength)),
        clipStatus: stream ? "recording" : "unavailable",
        motionScore: Number(score.toFixed(1)),
      };
      setEvents((current) => [event, ...current].slice(0, 80));
      setLastMotionSummary(`${object.notification} at ${formatTime(event.timestamp)}.`);
      sendDetectionNotification(object, event);
      void backupEvent(event);
      recordEventClip(event.id);
    },
    [aiEnabled, backupEvent, captureSnapshot, classifyObject, clipLength, deviceId, recordEventClip, sendDetectionNotification, stream],
  );

  useEffect(() => {
    if (mode !== "camera" || !stream || !motionEnabled) return undefined;
    const video = analysisVideoRef.current;
    if (!video) return undefined;
    const canvas = document.createElement("canvas");
    canvas.width = 96;
    canvas.height = 54;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) return undefined;

    let frame = 0;
    let lastCheck = 0;
    let lastEvent = 0;
    let previous: Uint8ClampedArray | null = null;
    const interval = batterySaving ? 1800 : 850;
    const pixelThreshold = Math.max(18, 72 - motionSensitivity * 0.58);
    const eventThreshold = Math.max(1.5, 13 - motionSensitivity * 0.12);

    const analyze = (time: number) => {
      if (time - lastCheck > interval && video.readyState >= 2) {
        lastCheck = time;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const data = context.getImageData(0, 0, canvas.width, canvas.height).data;
        if (previous) {
          let changed = 0;
          for (let index = 0; index < data.length; index += 16) {
            const delta = Math.abs(data[index] - previous[index]) + Math.abs(data[index + 1] - previous[index + 1]) + Math.abs(data[index + 2] - previous[index + 2]);
            if (delta > pixelThreshold) changed += 1;
          }
          const score = (changed / (data.length / 16)) * 100;
          setMotionScore(score);
          if (score > eventThreshold && time - lastEvent > 9000) {
            lastEvent = time;
            createDetectionEvent(score);
          }
        }
        previous = new Uint8ClampedArray(data);
      }
      frame = window.requestAnimationFrame(analyze);
    };

    frame = window.requestAnimationFrame(analyze);
    return () => window.cancelAnimationFrame(frame);
  }, [batterySaving, createDetectionEvent, mode, motionEnabled, motionSensitivity, stream]);

  const toggleLocalRecording = useCallback(() => {
    if (recordingState === "recording") {
      manualRecorderRef.current?.stop();
      return;
    }
    if (!stream || typeof MediaRecorder === "undefined") {
      setCameraError("Start Camera mode before recording, and use a browser with MediaRecorder support.");
      return;
    }
    try {
      const recorder = new MediaRecorder(stream, getMediaRecorderOptions());
      manualChunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) manualChunksRef.current.push(event.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(manualChunksRef.current, { type: recorder.mimeType || "video/webm" });
        setLatestRecordingUrl(URL.createObjectURL(blob));
        setRecordingState("idle");
        setRecordingStartedAt(null);
      };
      recorder.start(2000);
      manualRecorderRef.current = recorder;
      setRecordingState("recording");
      setRecordingStartedAt(new Date().toISOString());
      setCameraError("");
    } catch (error) {
      setCameraError(error instanceof Error ? error.message : "Unable to start local recording.");
    }
  }, [recordingState, stream]);

  const requestWakeLock = useCallback(async () => {
    const navigatorWithWakeLock = navigator as NavigatorWithWakeLock;
    if (!navigatorWithWakeLock.wakeLock) {
      setWakeLockStatus("Screen Wake Lock API is unavailable here; native Android foreground service is required for locked-screen operation.");
      return;
    }
    try {
      wakeLockRef.current = await navigatorWithWakeLock.wakeLock.request("screen");
      wakeLockRef.current.addEventListener("release", () => setWakeLockStatus("Wake lock released."));
      setWakeLockStatus("Wake lock active while this web app remains visible.");
    } catch (error) {
      setWakeLockStatus(error instanceof Error ? error.message : "Wake lock request failed.");
    }
  }, []);

  const releaseWakeLock = useCallback(() => {
    void wakeLockRef.current?.release();
    wakeLockRef.current = null;
    setWakeLockStatus("Wake lock released.");
  }, []);

  useEffect(() => {
    return () => {
      void wakeLockRef.current?.release();
    };
  }, []);

  const addPairedCamera = useCallback(
    (rawValue: string, connection: PairedCamera["connection"] = "Wi-Fi") => {
      const parsedId = parsePairingInput(rawValue);
      if (!parsedId) {
        setPairMessage("Enter a valid Camera Device ID or scan a QR payload.");
        return false;
      }
      setPairedCameras((current) => {
        const existing = current.find((camera) => camera.id === parsedId);
        if (existing) {
          return current.map((camera) => (camera.id === parsedId ? { ...camera, status: parsedId === deviceId && hasStream ? "Live" : "Ready" } : camera));
        }
        const camera: PairedCamera = {
          id: parsedId,
          name: parsedId === deviceId ? "This Camera Device" : `420 Camera ${current.length + 1}`,
          status: parsedId === deviceId && hasStream ? "Live" : "Ready",
          battery: parsedId === deviceId ? 100 : 82,
          quality: parsedId === deviceId && hasStream ? "Live" : "Secure",
          pairedAt: new Date().toISOString(),
          connection: parsedId === deviceId ? "This device" : connection,
          notifications: true,
        };
        return [camera, ...current];
      });
      setPairMessage(`${parsedId} paired successfully.`);
      return true;
    },
    [deviceId, hasStream],
  );

  const onPairSubmit = useCallback(() => {
    if (addPairedCamera(pairingInput, "Internet")) setPairingInput("");
  }, [addPairedCamera, pairingInput]);

  useEffect(() => {
    if (!scanActive) return undefined;
    let active = true;
    let animationFrame = 0;
    let scannerStream: MediaStream | null = null;

    const startScanner = async () => {
      if (!navigator.mediaDevices?.getUserMedia) {
        setScanMessage("This browser cannot access the camera for QR scanning.");
        return;
      }
      try {
        scannerStream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { ideal: "environment" } } });
        if (scanVideoRef.current) {
          scanVideoRef.current.srcObject = scannerStream;
          await scanVideoRef.current.play().catch(() => undefined);
        }
        const Detector = getBarcodeDetector();
        if (!Detector) {
          setScanMessage("QR preview active. Automatic decoding is unavailable in this browser; enter the ID manually.");
          return;
        }
        const detector = new Detector({ formats: ["qr_code"] });
        setScanMessage("Point the Viewer Device at the Camera Device QR code.");

        const scan = async () => {
          if (!active) return;
          const node = scanVideoRef.current;
          if (node && node.readyState >= 2) {
            try {
              const codes = await detector.detect(node);
              const rawValue = codes[0]?.rawValue;
              if (rawValue && addPairedCamera(rawValue, "Wi-Fi")) {
                setScanActive(false);
                return;
              }
            } catch {
              setScanMessage("Scanning for QR code...");
            }
          }
          animationFrame = window.requestAnimationFrame(scan);
        };
        animationFrame = window.requestAnimationFrame(scan);
      } catch {
        setScanMessage("Camera permission is required to scan a QR code.");
      }
    };

    void startScanner();
    return () => {
      active = false;
      window.cancelAnimationFrame(animationFrame);
      scannerStream?.getTracks().forEach((track) => track.stop());
    };
  }, [addPairedCamera, scanActive]);

  const toggleNotificationPref = useCallback((category: Category) => {
    setNotificationPrefs((current) => ({ ...current, [category]: !current[category] }));
  }, []);

  const removeCamera = useCallback((id: string) => {
    setPairedCameras((current) => current.filter((camera) => camera.id !== id));
    setSelectedCameraId((current) => (current === id ? null : current));
  }, []);

  const chooseMode = useCallback((nextMode: Exclude<Mode, "choose">) => {
    setMode(nextMode);
    setScreen("home");
  }, []);

  if (splashVisible) return <SplashScreen />;

  if (mode === "choose") return <ModePicker onSelect={chooseMode} />;

  return (
    <div className="min-h-screen bg-[#02040a] text-white">
      <video ref={analysisVideoRef} autoPlay muted playsInline className="fixed -left-[9999px] top-0 h-px w-px opacity-0" />
      <div className="mx-auto min-h-screen max-w-md overflow-hidden bg-[#060912] shadow-2xl shadow-black">
        <TopBar mode={mode} screen={screen} onSwitchMode={() => setMode("choose")} />
        <main>
          {screen === "home" && mode === "camera" ? (
            <CameraHome
              deviceId={deviceId}
              previewVideoRef={previewVideoRef}
              hasStream={hasStream}
              cameraPermission={cameraPermission}
              cameraError={cameraError}
              startCamera={startCamera}
              stopCamera={stopCamera}
              motionEnabled={motionEnabled}
              setMotionEnabled={setMotionEnabled}
              motionSensitivity={motionSensitivity}
              setMotionSensitivity={setMotionSensitivity}
              nightMode={nightMode}
              setNightMode={setNightMode}
              batterySaving={batterySaving}
              setBatterySaving={setBatterySaving}
              aiEnabled={aiEnabled}
              setAiEnabled={setAiEnabled}
              motionScore={motionScore}
              recordingState={recordingState}
              toggleLocalRecording={toggleLocalRecording}
              recordingStartedAt={recordingStartedAt}
              latestRecordingUrl={latestRecordingUrl}
              clipLength={clipLength}
              setClipLength={setClipLength}
              lastMotionSummary={lastMotionSummary}
              wakeLockStatus={wakeLockStatus}
              requestWakeLock={requestWakeLock}
              releaseWakeLock={releaseWakeLock}
              recentEvents={recentEvents}
            />
          ) : null}

          {screen === "home" && mode === "viewer" ? (
            <ViewerHome
              pairedCameras={pairedCameras}
              pairingInput={pairingInput}
              setPairingInput={setPairingInput}
              pairMessage={pairMessage}
              onPairSubmit={onPairSubmit}
              scanActive={scanActive}
              setScanActive={setScanActive}
              scanVideoRef={scanVideoRef}
              scanMessage={scanMessage}
              selectedCameraId={selectedCameraId}
              setSelectedCameraId={setSelectedCameraId}
              liveVideoRef={liveVideoRef}
              hasStream={hasStream}
              deviceId={deviceId}
              events={events}
              listenEnabled={listenEnabled}
              setListenEnabled={setListenEnabled}
              talkBackEnabled={talkBackEnabled}
              setTalkBackEnabled={setTalkBackEnabled}
            />
          ) : null}

          {screen === "events" ? <EventTimeline events={events} filter={eventFilter} setFilter={setEventFilter} /> : null}

          {screen === "settings" ? (
            <SettingsPage
              notificationPrefs={notificationPrefs}
              toggleNotificationPref={toggleNotificationPref}
              notificationPermission={notificationPermission}
              requestNotificationPermission={requestNotificationPermission}
              cloudBackup={cloudBackup}
              setCloudBackup={setCloudBackup}
              cloudEndpoint={cloudEndpoint}
              setCloudEndpoint={setCloudEndpoint}
              cloudStatus={cloudStatus}
              motionSensitivity={motionSensitivity}
              setMotionSensitivity={setMotionSensitivity}
              clipLength={clipLength}
              setClipLength={setClipLength}
              batterySaving={batterySaving}
              setBatterySaving={setBatterySaving}
              pairedCameras={pairedCameras}
              removeCamera={removeCamera}
            />
          ) : null}

          {screen === "about" ? <AboutPage /> : null}
        </main>
        <BottomNav screen={screen} mode={mode} onScreenChange={setScreen} />
      </div>
    </div>
  );
}